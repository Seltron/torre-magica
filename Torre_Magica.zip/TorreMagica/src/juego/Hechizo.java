package juego;

import java.awt.*;
import java.util.ArrayList;

import entorno.Entorno;
public class Hechizo {
		ArrayList<Rectangle>  hechizos;
		Entorno entorno;
		Mago mago;
		boolean cargado;
		int posx;
		int posy;
		
	//Constructor
	Hechizo(Entorno entorno,Mago mago){
		this.entorno = entorno;
		this.mago = mago;
		this.hechizos = new ArrayList<Rectangle>();
		posx = 0;
		posy = 0;
		Rectangle hechizo0 = new Rectangle(posx, posy, 30, 50);
		Rectangle hechizo1 = new Rectangle(posx, posy, 30, 50);
		Rectangle hechizo2 = new Rectangle(posx, posy, 30, 50);
		Rectangle hechizo3 = new Rectangle(posx, posy, 30, 50);
		Rectangle hechizo4 = new Rectangle(posx, posy, 30, 50);
		Rectangle hechizo5 = new Rectangle(posx, posy, 30, 50);
		Rectangle hechizo6 = new Rectangle(posx, posy, 30, 50);
		hechizos.add(hechizo0);
		hechizos.add(hechizo1);
		hechizos.add(hechizo2);
		hechizos.add(hechizo3);
		hechizos.add(hechizo4);
		hechizos.add(hechizo5);
		hechizos.add(hechizo6);
		
		cargado = false;
	}

	//Metodos
	
	void dibujarHechizo(Entorno entorno) {
		entorno.dibujarRectangulo(hechizos.get(mago.numeroPeldanio).x, hechizos.get(mago.numeroPeldanio).y, 30, 50, 0, Color.BLUE);
	}
	
	void movimientoDerecha(Rectangle hechizo) {
			hechizo.x += 1;
		}
	
	void movimientoIzquierda(Rectangle hechizo) {

				hechizo.x -= 1;
		
	}
	
	

	void lanzarHechizoDet(Entorno entorno) {
		//this.posx = mago.obtenx();
		if(mago.tocoPiso()) {
			hechizos.get(mago.numeroPeldanio).y = mago.mago.y;
			if(mago.seMovioDerecha && cargado) {
				//if(hechizos.get(mago.numeroPeldanio).x <= 754) {
					System.out.println("salio para la derecha " + "hechizo numero " + mago.numeroPeldanio );
					hechizos.get(mago.numeroPeldanio).x = mago.mago.x;
					for (int i = hechizos.get(mago.numeroPeldanio).x; i < 770; i++) {
						//hechizos.get(mago.numeroPeldanio).x += 1;
						movimientoDerecha(hechizos.get(mago.numeroPeldanio));
						//entorno.dibujarRectangulo(hechizos.get(mago.numeroPeldanio).x, hechizos.get(mago.numeroPeldanio).y, 30, 50, 0, Color.BLUE);
					}
					
				//}
				//else {
			//		hechizos.get(mago.numeroPeldanio).setLocation(posx, 1000);
				//}
				cargado = false;
				}
			else if(!mago.seMovioDerecha && cargado) {
				System.out.println("salio para la izquierda "  + "hechizo numero " + mago.numeroPeldanio);
				//if(hechizos.get(mago.numeroPeldanio).x >= 23) {
					
					hechizos.get(mago.numeroPeldanio).x = mago.mago.x;
					for (int i = hechizos.get(mago.numeroPeldanio).x; i > 23; i--) {
						//hechizos.get(mago.numeroPeldanio).x -= 1 ;
						movimientoIzquierda(hechizos.get(mago.numeroPeldanio));
					//}
					
					
				}
				hechizos.get(mago.numeroPeldanio).setLocation(posx, posy);
				//else {
				//	hechizos.get(mago.numeroPeldanio).setLocation(posx, 1000);
				//}
				cargado = false;
			}
		}
		else {
			hechizos.get(mago.numeroPeldanio).setLocation(posx, posy);
			cargado = true;
			}
	

		

	}

}