package juego;

import entorno.Entorno;
import entorno.Herramientas;
import java.awt.*;

public class Fondo {
	Rectangle [] peldanios;
	Rectangle [] paredes;
	Image imagenFondo;
	Image imagenTextura;
	Image imagenTextura2;
	Image imagenTextura3;
	Image imagenTextura4;
	Image imagenTextura5;
	Image imagenTextura6;
	Image imagenTextura7;
	

	
	Fondo(){
		peldanios = new Rectangle[7];
		paredes = new Rectangle[2];
		peldanios[0] = new Rectangle(400-250, 100-38, 500, 20);
		peldanios[1] = new Rectangle(100-100, 200-37, 200, 20);
		peldanios[2] = new Rectangle(700-105, 200-37, 210, 20);
		peldanios[3]= new Rectangle(400-200, 300-36, 400, 20);
		peldanios[4]= new Rectangle(400-270, 400-36, 550, 20);
		peldanios[5] = new Rectangle(100-100, 550-80, 200, 110);
		peldanios[6] = new Rectangle(700-105, 550-80, 210, 110);
		paredes[0] = new Rectangle(0, 0, 400, 20);
		paredes[1] = new Rectangle(800, 0, 400, 20);
		imagenFondo = Herramientas.cargarImagen("juego/Pared_Fondo2.png");
		imagenTextura = Herramientas.cargarImagen("juego/Peldanio_lat_der.png");
		imagenTextura2 = Herramientas.cargarImagen("juego/Techo_der.png");
		imagenTextura3 = Herramientas.cargarImagen("juego/Columna.png");
		imagenTextura4 = Herramientas.cargarImagen("juego/1_central.png");
		imagenTextura5 = Herramientas.cargarImagen("juego/2_central.png");	
		imagenTextura6 = Herramientas.cargarImagen("juego/3_central.png");
		imagenTextura7 = Herramientas.cargarImagen("juego/Peldanio_inf_der.png");
		
	
	}
	
	public void Dibujar(Entorno entorno){ 
	
		//entorno.dibujarRectangulo(0.0, 0.0, 2000.0, 2000.0, 0.0, Color.green);
		entorno.dibujarImagen(imagenFondo, 400, 300, 0, 1);// Fondo
		
		//entorno.dibujarRectangulo(400.0, 100.0, 500.0, 20.0, 0.0, Color.red);
		
		entorno.dibujarImagen(imagenTextura4, 400, 102, 0, 1);//primer barra central
		
		
		//entorno.dibujarRectangulo(100.0, 200.0, 200.0, 20.0, 0.0, Color.red);
		entorno.dibujarImagen(imagenTextura, 100, 200, 0, 1);//primer barra izq
		
		
		//entorno.dibujarRectangulo(700.0, 200.0, 210.0, 20.0, 0.0, Color.red);
		entorno.dibujarImagen(imagenTextura, 700, 200, 0, 1);//primer bara derecha
		
		//entorno.dibujarRectangulo(400.0, 300.0, 400.0, 20.0, 0.0, Color.red);
		entorno.dibujarImagen(imagenTextura5, 400, 300.5, 0, 1);// segunda barra central
		
		//entorno.dibujarRectangulo(400.0, 400.0, 550.0, 20.0, 0.0, Color.red);
		entorno.dibujarImagen(imagenTextura6, 400, 400.5, 0, 1); //tercer barra central
		
		//entorno.dibujarRectangulo(0.0, 0.0, 30.0,1000.0, 0.0, Color.blue); 
		entorno.dibujarImagen(imagenTextura3, 0.0, 0.0, 0, 2); //barra lateral izq
		
		//entorno.dibujarRectangulo(800.0, 0.0, 30.0, 1000.0, 0.0, Color.blue); // 
		entorno.dibujarImagen(imagenTextura3, 800.0, 0.0, 0, 2);//barra lateral derecha
		
		//entorno.dibujarRectangulo(100.0, 550.0, 200.0, 110.0, 0.0, Color.red);
		entorno.dibujarImagen(imagenTextura7, 0.0, 600, 0, 1.9);//ultima barra inferior izq
		
		//entorno.dibujarRectangulo(700.0, 550.0, 230.0, 110.0, 0.0, Color.red);
		entorno.dibujarImagen(imagenTextura7, 800.0, 600, 0, 1.9); //ultima barrra inferior der.
		
		//entorno.dibujarRectangulo(0.0, 0.0, 400.0, 20.0, 0.0, Color.darkGray); //barra superior izq
		entorno.dibujarImagen(imagenTextura2, 60, 0.0, 0, 1.5);
		
		//entorno.dibujarRectangulo(800.0, 0.0, 400.0, 20.0, 0.0, Color.darkGray); //barra superior der
		entorno.dibujarImagen(imagenTextura2, 750, 0, 0, 1.5);
	}
}