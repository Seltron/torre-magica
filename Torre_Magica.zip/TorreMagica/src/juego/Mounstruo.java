package juego;

import java.awt.Color;
import java.awt.Rectangle;
import java.util.ArrayList;

import entorno.Entorno;

public class Mounstruo {
	Fondo fondos;
	Entorno entorno;
	Mago mago;
	Hechizo hechizo;
	ArrayList<Rectangle>  enemigos;
	int u;
	int h;
	int a;
	int c;
	double congelamiento;
	
	//Constructor
	Mounstruo(Fondo fond, Entorno entor, Mago mago, Hechizo hechizo){
		this.mago = mago;
		this.fondos = fond;
		this.entorno = entor;
		this.hechizo = hechizo;
		this.enemigos = new ArrayList<Rectangle>();
		Rectangle enemigo0= new Rectangle(370 - 15,260 - 25, 30, 50);
		Rectangle enemigo1= new Rectangle(420 - 15,260 - 25, 30, 50);
		Rectangle enemigo2= new Rectangle(250 - 15,360 - 25, 30, 50);
		Rectangle enemigo3= new Rectangle(550 - 15,360 - 25, 30, 50);
		enemigos.add(enemigo0);
		enemigos.add(enemigo1);
		enemigos.add(enemigo2);
		enemigos.add(enemigo3);
		u = 1;
		a = 1;
		h = -1;
		c = -1;
		congelamiento = 0;
	}
	
	//Metodos
	void movimientoIzq() {
		enemigos.get(0).x -= u;
		enemigos.get(2).x -= a;
		if(enemigos.get(0).x <= 20) {
			u = u * (-1);
		}
		if(enemigos.get(0).x >= 754) {
			u = u * (-1);
		}
		
		if(enemigos.get(2).x <= 20) {
			a = a * (-1);
		}
		if(enemigos.get(2).x >= 754 ) {
			a = a * (-1);
		}
		
	}
	
	void movimientoDer() {
		enemigos.get(1).x -= h;
		enemigos.get(3).x -= c;
		if(enemigos.get(1).x <= 20) {
			h = h * (-1);
		}
		if(enemigos.get(1).x >= 754 ) {
			h = h * (-1);
		}
		
		if(enemigos.get(3).x <= 20) {
			c = c * (-1);
		}
		if(enemigos.get(3).x >= 754 ) {
			c = c * (-1);
		}
	}
	
	void ReUbicarEnemigo() {
		if(enemigos.get(0).y >= 770) {
			enemigos.get(0).y = 0;
		}
		if(enemigos.get(1).y >= 770) {
			enemigos.get(1).y = 0;
		}
		if(enemigos.get(2).y >= 770) {
			enemigos.get(2).y = 0;
		}
		if(enemigos.get(3).y >= 770) {
			enemigos.get(3).y = 0;
		}
	}
	
	void DibujarEnemigos() {
		entorno.dibujarRectangulo( enemigos.get(0).getX() + 15, enemigos.get(0).getY(), 30.0, 50.0, 0.0, Color.RED);
		entorno.dibujarRectangulo( enemigos.get(1).getX() + 15, enemigos.get(1).getY(), 30.0, 50.0, 0.0, Color.RED);
		entorno.dibujarRectangulo( enemigos.get(2).getX() + 15, enemigos.get(2).getY(), 30.0, 50.0, 0.0, Color.RED);
		entorno.dibujarRectangulo( enemigos.get(3).getX() + 15, enemigos.get(3).getY(), 30.0, 50.0, 0.0, Color.RED);
	}
	
	void choqueP() {
		for (int i = 0; i < enemigos.size(); i++) {
			if(enemigos.get(i).getX() >= 770.0) {
				enemigos.get(i).x = enemigos.get(i).intersection(fondos.paredes[1]).x - 25;	
			}
			if(enemigos.get(i).getX() <= 20.0) {
				enemigos.get(i).x = enemigos.get(i).intersection(fondos.paredes[0]).x + 10;
			}
		}
	}
	
	void caidaEnemigo() {
	for(int j = 0; j < enemigos.size();j++)
	{
			for (int i = 0; i < 7; i++) {
				if(enemigos.get(j).intersects(fondos.peldanios[i])) {
					enemigos.get(j).y = fondos.peldanios[i].y;	
				}
				if(!(enemigos.get(j).intersects(fondos.peldanios[i]))) {
					enemigos.get(j).y+= 1;
				}
			}
		}
	}
	
	void choqueM() {
        for(int j = 0; j < enemigos.size(); j++){
             if(enemigos.get(j).intersects(mago.mago)){
            	System.out.println("perdiste");
            	 entorno.hide(); 
            	
              }
             else {
            	 //System.out.println("esto no es coca");
             }
        }
	}
	void choqueHechizo() {  //devuelve verdadero al momento de chocar con el hechizo
		for (int i = 0; i < enemigos.size(); i++) {
			for (int j = 0; j < hechizo.hechizos.size(); j++) {
				if(enemigos.get(i).intersects(hechizo.hechizos.get(j))){
					System.out.println("enemigo congelado por "+ hechizo.hechizos.get(j) );
					/*if(congelamiento <= 1000) {
						enemigos.get(i).x = enemigos.get(i).intersection(mago.hechizos.get(j)).x;
						congelamiento +=0.5;
					}*/
					//enemigos.get(i).move(x, y);
				}
			}
			
			
		}
	}
	
	
	
	
	

}
