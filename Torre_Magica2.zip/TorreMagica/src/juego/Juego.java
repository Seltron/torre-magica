package juego;


import entorno.Entorno;
import entorno.InterfaceJuego;

public class Juego extends InterfaceJuego
{
	// El objeto Entorno que controla el tiempo y otros
	private Entorno entorno;
	private Mago mago;
	private Mounstruo enemigos;
	private Hechizo hechizo;
	Fondo fondo;
	
	// Variables y métodos propios de cada grupo
	// ...
	
	Juego()
	{
		// Inicializa el objeto entorno
		this.entorno = new Entorno(this, "Torre Magica - Grupo Dabul - Krujoski - Rages - Casella - V0.01", 800, 600);
		 
		// Inicializar lo que haga falta para el juego
		// ...

		// Inicia el juego!
		fondo =  new Fondo();
		mago = new Mago(this.entorno, fondo);
		hechizo = new Hechizo(this.entorno, mago);
		enemigos =  new Mounstruo(fondo, this.entorno, mago, hechizo);
		
		this.entorno.iniciar();
		
		
	}

	/**
	 * Durante el juego, el método tick() será ejecutado en cada instante y 
	 * por lo tanto es el método más importante de esta clase. Aquí se debe 
	 * actualizar el estado interno del juego para simular el paso del tiempo 
	 * (ver el enunciado del TP para mayor detalle).
	 */
	public void tick()
	{
		

		fondo.Dibujar(this.entorno);
		mago.DibujarM(this.entorno);
		enemigos.DibujarEnemigos();
		mago.caida();
		mago.reUbicar();
		if(entorno.estaPresionada(entorno.TECLA_DERECHA)){
			mago.avanceDerecha(this.entorno);
		}
		if(entorno.estaPresionada(entorno.TECLA_IZQUIERDA)){
			mago.avanceIzquierda(this.entorno);
		}
		/*if(entorno.estaPresionada(entorno.TECLA_ARRIBA)) {
			mago.salto(this.entorno);
		}*/
		enemigos.movimientoIzq();
		enemigos.movimientoDer();
		enemigos.ReUbicarEnemigo();
		mago.choqueP();			
		//enemigos.choqueM();
		enemigos.choqueP();
		mago.tocoPiso();
		if(hechizo.lanzarHechizoDer()) {
			hechizo.dibujarHechizo(this.entorno);
			for (int i = hechizo.hechizo0.x; i < 650; i++) {
				hechizo.movimientoDerecha();	
			}
		}
		else if(hechizo.lanzarHechizoizq()) {
			hechizo.dibujarHechizo(this.entorno);
			for (int i = hechizo.hechizo0.x; i > 23; i--) {
				hechizo.movimientoIzquierda();
			}
			
			
		}
		enemigos.caidaEnemigo();
		enemigos.choqueHechizo();
		entorno.escribirTexto("cargado= " + hechizo.cargado, 200, 200);
		entorno.escribirTexto("peldaño numero= " + mago.numeroPeldanio, 100, 150);
		entorno.escribirTexto("posx hechiz= " + hechizo.hechizo0.x +"posy hechiz=" +"  " + hechizo.hechizo0.y, 250, 250);

	}
	

	@SuppressWarnings("unused")
	public static void main(String[] args)
	{
		Juego juego = new Juego();


	}
}
