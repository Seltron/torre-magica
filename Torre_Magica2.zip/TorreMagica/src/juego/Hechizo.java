package juego;

import java.awt.*;
import java.util.ArrayList;

import entorno.Entorno;
public class Hechizo {
		//ArrayList<Rectangle>  hechizos;
		Entorno entorno;
		Mago mago;
		boolean cargado;
		int posx;
		int posy;
		Rectangle hechizo0;
		
	//Constructor
	Hechizo(Entorno entorno,Mago mago){
		this.entorno = entorno;
		this.mago = mago;
		//this.hechizos = new ArrayList<Rectangle>();
		//Rectangle
		hechizo0 = new Rectangle(0, 0, 30, 50);
//		Rectangle hechizo1 = new Rectangle(posx, posy, 30, 50);
//		Rectangle hechizo2 = new Rectangle(posx, posy, 30, 50);
//		Rectangle hechizo3 = new Rectangle(posx, posy, 30, 50);
//		Rectangle hechizo4 = new Rectangle(posx, posy, 30, 50);
//		Rectangle hechizo5 = new Rectangle(posx, posy, 30, 50);
//		Rectangle hechizo6 = new Rectangle(posx, posy, 30, 50);
//		hechizos.add(hechizo0);
//		hechizos.add(hechizo1);
//		hechizos.add(hechizo2);
//		hechizos.add(hechizo3);
//		hechizos.add(hechizo4);
//		hechizos.add(hechizo5);
//		hechizos.add(hechizo6);
		
		cargado = false;
	}

	//Metodos
	
	void dibujarHechizo(Entorno entorno) {
		entorno.dibujarRectangulo(this.hechizo0.x, this.hechizo0.y, 30, 50, 0, Color.BLUE);
	}
	
	void movimientoDerecha() {
			this.hechizo0.x += 5;
		}
	
	void movimientoIzquierda() {
		this.hechizo0.x -= 5;
		
	}
	
	

	boolean lanzarHechizoDer() {
		if(mago.tocoPiso()) {
			this.hechizo0.y = mago.mago.y;
			if(mago.seMovioDerecha && cargado) {
				this.hechizo0.x = mago.mago.x;
				cargado = false;	
				return true;
				}
			else {
				cargado = false;
				return false;
				}
			}
		else {
			this.hechizo0.setLocation(0, 0);
			cargado = true;
			return false;
			}
	}
	
	boolean lanzarHechizoizq() {
		if(mago.tocoPiso()) {
			this.hechizo0.y = mago.mago.y;
			if(!mago.seMovioDerecha && cargado) {
				this.hechizo0.x = mago.mago.x;
				cargado = false;	
				return true;
				}
			else {
				cargado = false;
				return false;
				}
			}
		else {
			this.hechizo0.setLocation(0, 0);
			cargado = true;
			return false;
			}
	}

}