package juego;
import java.awt.*;
import entorno.Entorno;
	public class Mago {
		Entorno entorno;
		int cont;
		Rectangle mago;
		Fondo  fondos;
		boolean seMovioDerecha;
		int numeroPeldanio;
		
		//Constructor
		Mago(Entorno entorno, Fondo fondos){
			mago = new Rectangle(400 - 15, 70 , 30, 50);
			this.fondos = fondos;
			seMovioDerecha = true;
			numeroPeldanio =  0;
			
			}
		
		//Metodos
		public void DibujarM(Entorno entorno){
			
			entorno.dibujarRectangulo(this.mago.x + 15, this.mago.y , 30.0, 50.0, 0.0, Color.WHITE);
				
			
			
		}
		
		public void avanceIzquierda(Entorno entorno){
			this.mago.x -= 5;
			this.seMovioDerecha = false;
			
		}
		
		public void avanceDerecha(Entorno entorno){
			this.mago.x += 5;
			this.seMovioDerecha = true;
			
		}
		
		public void salto(Entorno entorno) {
				this.mago.y -= 31;
			
			
		}
		
		

			
		void caida() {	
			for(int j = 0; j < 7; j++)
			{
					if(!(mago.intersects(fondos.peldanios[j])) ) {
						this.mago.y += 1;
					}
					if((mago.intersects(fondos.peldanios[j])) ) {
						this.mago.y = fondos.peldanios[j].y;
					}
				}
		}
		
		void reUbicar() {
			if(this.mago.y > 600) {
				this.mago.y = 0;
			}
		}
		
		void choqueP() {
			if(this.mago.x >= 750.0) {
				this.mago.x = fondos.paredes[1].x - 46;
				
				
			}
			if(this.mago.x <= 20.0) {
				this.mago.x = fondos.paredes[0].x + 16;	
			}
		}
		
//		boolean tocoPiso(){
//			boolean tocoPiso = false;
//			for(int j = 0 ; j <= fondos.peldanios.length; j++){
//				if((mago.intersects(fondos.peldanios[j])==false &&  mago.intersects(fondos.peldanios[j+1])==true)) {
//					indice = j+1;
//					System.out.println(indice);
//					tocoPiso = true;
//					}
//				if(j == 6) {
//					if(!(mago.intersects(fondos.peldanios[5]) &&  mago.intersects(fondos.peldanios[0])) ||
//						!(mago.intersects(fondos.peldanios[6]) &&  mago.intersects(fondos.peldanios[0]))) {
//						indice = 0;
//						System.out.println(indice);
//						tocoPiso = true;
//				}
//				}
//				
//			}
//			return tocoPiso;
//				
//		}	
		
		boolean tocoPiso() {
			boolean tocoPiso = false;
			for (int i = 0; i < fondos.peldanios.length; i++) {
				if(mago.intersects(fondos.peldanios[i])) {
					numeroPeldanio = i;
					tocoPiso = true;
//					System.out.println("Est� parado sobre " + numeroPeldanio);
				}
			}
			return tocoPiso;
		}
		
		
		
		
		public int  obtenx()
        {
             return (int)this.mago.x;
        }
        public int  obteny()
        {
             return (int) this.mago.y;
        }
		
		
		
	}